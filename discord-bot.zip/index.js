const { Client, GatewayIntentBits, Collection, REST, Routes } = require("discord.js")
const fs = require("fs")
const path = require("path")
const { token, prefix } = require("./config.json")

// Create a new client instance
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
})

// Create collections for commands
client.commands = new Collection()

// Load commands
const commandFolders = fs.readdirSync("./commands")
const commands = []
for (const folder of commandFolders) {
  const commandFiles = fs.readdirSync(`./commands/${folder}`).filter((file) => file.endsWith(".js"))
  for (const file of commandFiles) {
    const command = require(`./commands/${folder}/${file}`)
    client.commands.set(command.name, command)
    if (command.data) {
      commands.push(command.data.toJSON())
    }
  }
}

// Load events
const eventFiles = fs.readdirSync("./events").filter((file) => file.endsWith(".js"))
for (const file of eventFiles) {
  const event = require(`./events/${file}`)
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args, client))
  } else {
    client.on(event.name, (...args) => event.execute(...args, client))
  }
}

const rest = new REST({ version: "10" }).setToken(token)
;(async () => {
  try {
    console.log("Slash komutları yükleniyor...")
    await rest.put(Routes.applicationCommands(client.user?.id || ""), { body: commands })
    console.log("Slash komutları başarıyla yüklendi!")
  } catch (error) {
    console.error(error)
  }
})()

// Handle messages
client.on("messageCreate", (message) => {
  if (!message.content.startsWith(prefix) || message.author.bot) return

  const args = message.content.slice(prefix.length).trim().split(/ +/)
  const commandName = args.shift().toLowerCase()

  const command = client.commands.get(commandName)

  if (!command) return

  try {
    command.execute(message, args, client)
  } catch (error) {
    console.error(error)
    message.reply("Komutu çalıştırırken bir hata oluştu!")
  }
})

// Login to Discord
client.login(token)
