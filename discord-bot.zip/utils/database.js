const fs = require("fs")
const path = require("path")

const dbPath = path.join(__dirname, "..", "database.json")

// Database utility functions
const db = {
  // Get all data
  getData: () => {
    const data = JSON.parse(fs.readFileSync(dbPath, "utf8"))
    return data
  },

  // Save data
  saveData: (data) => {
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2), "utf8")
  },

  // Get user data
  getUser: function (userId) {
    const data = this.getData()
    if (!data.users[userId]) {
      data.users[userId] = { id: userId }
      this.saveData(data)
    }
    return data.users[userId]
  },

  // Update user data
  updateUser: function (userId, userData) {
    const data = this.getData()
    data.users[userId] = { ...data.users[userId], ...userData }
    this.saveData(data)
    return data.users[userId]
  },

  // Get guild data
  getGuild: function (guildId) {
    const data = this.getData()
    if (!data.guilds[guildId]) {
      data.guilds[guildId] = { id: guildId }
      this.saveData(data)
    }
    return data.guilds[guildId]
  },

  // Update guild data
  updateGuild: function (guildId, guildData) {
    const data = this.getData()
    data.guilds[guildId] = { ...data.guilds[guildId], ...guildData }
    this.saveData(data)
    return data.guilds[guildId]
  },
}

module.exports = db
