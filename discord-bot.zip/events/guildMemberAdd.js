const { AttachmentBuilder } = require("discord.js")
const Canvas = require("@napi-rs/canvas")

module.exports = {
  name: "guildMemberAdd",
  async execute(member) {
    const channel = member.guild.channels.cache.find((ch) => ch.name === "hoş-geldin")
    if (!channel) return

    const canvas = Canvas.createCanvas(700, 250)
    const ctx = canvas.getContext("2d")

    // Background
    ctx.fillStyle = "#23272A"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Text
    ctx.font = "35px sans-serif"
    ctx.fillStyle = "#ffffff"
    ctx.fillText("Hoş Geldin!", canvas.width / 2.5, canvas.height / 3.5)

    ctx.font = "30px sans-serif"
    ctx.fillStyle = "#ffffff"
    ctx.fillText(member.user.username, canvas.width / 2.5, canvas.height / 1.8)

    // Avatar
    ctx.beginPath()
    ctx.arc(125, 125, 100, 0, Math.PI * 2, true)
    ctx.closePath()
    ctx.clip()

    const avatar = await Canvas.loadImage(member.user.displayAvatarURL({ extension: "jpg" }))
    ctx.drawImage(avatar, 25, 25, 200, 200)

    const attachment = new AttachmentBuilder(await canvas.encode("png"), { name: "hosgeldin.png" })

    channel.send({
      content: `${member} sunucumuza hoş geldin! Artık **${member.guild.memberCount}** kişiyiz!`,
      files: [attachment],
    })
  },
}
