const { SlashCommandBuilder, ChannelType, PermissionFlagsBits } = require("discord.js")

module.exports = {
  name: "ticket-ac",
  description: "Yeni bir destek talebi oluşturur.",
  data: new SlashCommandBuilder().setName("ticket-ac").setDescription("Yeni bir destek talebi oluşturur"),
  async executeSlash(interaction) {
    const ticketChannel = await interaction.guild.channels.create({
      name: `ticket-${interaction.user.username}`,
      type: ChannelType.GuildText,
      permissionOverwrites: [
        {
          id: interaction.guild.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: interaction.user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
        },
      ],
    })

    await ticketChannel.send(
      `Merhaba ${interaction.user}! Destek talebiniz oluşturuldu. Yetkili ekibimiz en kısa sürede size yardımcı olacaktır.`,
    )

    await interaction.reply({
      content: `✅ Destek talebiniz oluşturuldu: ${ticketChannel}`,
      ephemeral: true,
    })
  },
}
