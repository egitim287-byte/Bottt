const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js")

module.exports = {
  name: "ticket-kapat",
  description: "Destek talebini kapatır.",
  data: new SlashCommandBuilder()
    .setName("ticket-kapat")
    .setDescription("Destek talebini kapatır")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async executeSlash(interaction) {
    if (!interaction.channel.name.startsWith("ticket-")) {
      return interaction.reply({ content: "Bu komut sadece ticket kanallarında kullanılabilir!", ephemeral: true })
    }

    await interaction.reply("Ticket 5 saniye içinde kapatılacak...")
    setTimeout(async () => {
      await interaction.channel.delete()
    }, 5000)
  },
}
