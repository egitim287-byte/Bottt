const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js")

module.exports = {
  name: "rutbe-al",
  description: "Roblox grubunda kullanıcıdan rütbe alır.",
  data: new SlashCommandBuilder()
    .setName("rutbe-al")
    .setDescription("Roblox grubunda kullanıcıdan rütbe alır")
    .addStringOption((option) => option.setName("grup-id").setDescription("Roblox grup ID'si").setRequired(true))
    .addStringOption((option) =>
      option.setName("kullanici-id").setDescription("Roblox kullanıcı ID'si").setRequired(true),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  async executeSlash(interaction) {
    const grupId = interaction.options.getString("grup-id")
    const kullaniciId = interaction.options.getString("kullanici-id")

    await interaction.reply({
      content: `⚠️ Rütbe alma işlemi için Roblox API anahtarı gereklidir. Bu özellik şu anda manuel olarak yapılandırılmalıdır.\n\nGrup ID: ${grupId}\nKullanıcı ID: ${kullaniciId}`,
      ephemeral: true,
    })
  },
}
