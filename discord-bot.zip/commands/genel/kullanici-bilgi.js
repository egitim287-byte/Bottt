const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js")

module.exports = {
  name: "kullanıcı",
  description: "Kullanıcı hakkında detaylı bilgi verir.",
  async execute(message, args) {
    // Get the target user (mentioned user, ID, or message author)
    let user

    if (message.mentions.users.size > 0) {
      user = message.mentions.users.first()
    } else if (args[0]) {
      try {
        user = await message.client.users.fetch(args[0])
      } catch (error) {
        user = message.author
      }
    } else {
      user = message.author
    }

    // Get member object if user is in the server
    const member =
      message.guild.members.cache.get(user.id) || (await message.guild.members.fetch(user.id).catch(() => null))

    // Calculate dates
    const createdAt = Math.floor(user.createdTimestamp / 1000)
    const joinedAt = member ? Math.floor(member.joinedTimestamp / 1000) : null

    // Get user badges
    const badges = getUserBadges(user)

    // Create embed
    const embed = new EmbedBuilder()
      .setTitle(`${user.username} Kullanıcı Bilgisi`)
      .setColor(member?.displayHexColor || "#5865F2")
      .setThumbnail(user.displayAvatarURL({ size: 1024, dynamic: true }))
      .addFields({
        name: "👤 Kullanıcı Bilgileri",
        value:
          `**ID:** ${user.id}\n` +
          `**Tag:** ${user.tag}\n` +
          `**Oluşturulma Tarihi:** <t:${createdAt}:F> (<t:${createdAt}:R>)\n` +
          `**Bot mu?** ${user.bot ? "Evet" : "Hayır"}\n` +
          `**Rozetler:** ${badges.length > 0 ? badges.join(" ") : "Yok"}`,
      })

    // Add member information if available
    if (member) {
      // Get roles (excluding @everyone)
      const roles = member.roles.cache
        .filter((role) => role.id !== message.guild.id)
        .sort((a, b) => b.position - a.position)
        .map((role) => role.toString())

      // Get member presence info
      const status = member.presence ? getStatusEmoji(member.presence.status) : "⚫ Çevrimdışı"
      const activity = member.presence?.activities[0]
        ? `${getActivityTypeEmoji(member.presence.activities[0].type)} ${member.presence.activities[0].name}`
        : "Yok"

      embed.addFields(
        {
          name: "📋 Sunucu Bilgileri",
          value:
            `**Sunucuya Katılma:** <t:${joinedAt}:F> (<t:${joinedAt}:R>)\n` +
            `**Sunucu Takma Adı:** ${member.nickname || "Yok"}\n` +
            `**Durum:** ${status}\n` +
            `**Aktivite:** ${activity}\n` +
            `**En Yüksek Rol:** ${member.roles.highest.toString()}`,
        },
        {
          name: `🎭 Roller [${roles.length}]`,
          value:
            roles.length > 0
              ? roles.length > 15
                ? roles.slice(0, 15).join(", ") + ` ve ${roles.length - 15} daha...`
                : roles.join(", ")
              : "Yok",
        },
      )

      // Check for permissions
      const keyPermissions = getKeyPermissions(member)
      if (keyPermissions.length > 0) {
        embed.addFields({ name: "🔑 Önemli Yetkiler", value: keyPermissions.join(", ") })
      }
    }

    // Create buttons
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setLabel("Avatar")
        .setStyle(ButtonStyle.Link)
        .setURL(user.displayAvatarURL({ size: 4096, dynamic: true })),
      new ButtonBuilder()
        .setLabel("Banner")
        .setStyle(ButtonStyle.Link)
        .setURL(`https://discord.com/users/${user.id}`)
        .setDisabled(!user.banner),
    )

    // Send the embed
    message.channel.send({ embeds: [embed], components: [row] })
  },
}

// Helper functions
function getUserBadges(user) {
  const badges = []
  const flags = user.flags ? user.flags.toArray() : []

  if (flags.includes("Staff")) badges.push("<:discord_staff:1234567890>")
  if (flags.includes("Partner")) badges.push("<:partner:1234567890>")
  if (flags.includes("CertifiedModerator")) badges.push("<:moderator:1234567890>")
  if (flags.includes("Hypesquad")) badges.push("<:hypesquad:1234567890>")
  if (flags.includes("HypeSquadOnlineHouse1")) badges.push("<:bravery:1234567890>")
  if (flags.includes("HypeSquadOnlineHouse2")) badges.push("<:brilliance:1234567890>")
  if (flags.includes("HypeSquadOnlineHouse3")) badges.push("<:balance:1234567890>")
  if (flags.includes("BugHunterLevel1")) badges.push("<:bug_hunter:1234567890>")
  if (flags.includes("BugHunterLevel2")) badges.push("<:bug_hunter_gold:1234567890>")
  if (flags.includes("VerifiedDeveloper")) badges.push("<:verified_developer:1234567890>")
  if (flags.includes("VerifiedBot")) badges.push("<:verified_bot:1234567890>")
  if (flags.includes("EarlySupporter")) badges.push("<:early_supporter:1234567890>")
  if (flags.includes("PremiumEarlySupporter")) badges.push("<:premium_early_supporter:1234567890>")

  // Since we don't have actual emoji IDs, let's use text representations
  return flags.map((flag) => `\`${flag}\``)
}

function getStatusEmoji(status) {
  switch (status) {
    case "online":
      return "🟢 Çevrimiçi"
    case "idle":
      return "🟡 Boşta"
    case "dnd":
      return "🔴 Rahatsız Etmeyin"
    case "invisible":
    case "offline":
    default:
      return "⚫ Çevrimdışı"
  }
}

function getActivityTypeEmoji(type) {
  switch (type) {
    case 0:
      return "🎮" // Playing
    case 1:
      return "🎥" // Streaming
    case 2:
      return "🎧" // Listening
    case 3:
      return "👀" // Watching
    case 4:
      return "🏆" // Competing
    case 5:
      return "🎭" // Custom
    default:
      return "📱"
  }
}

function getKeyPermissions(member) {
  const permissions = []

  if (member.permissions.has("Administrator")) {
    return ["Yönetici (Tüm Yetkiler)"]
  }

  if (member.permissions.has("ManageGuild")) permissions.push("Sunucuyu Yönet")
  if (member.permissions.has("BanMembers")) permissions.push("Üyeleri Yasakla")
  if (member.permissions.has("KickMembers")) permissions.push("Üyeleri At")
  if (member.permissions.has("ManageChannels")) permissions.push("Kanalları Yönet")
  if (member.permissions.has("ManageRoles")) permissions.push("Rolleri Yönet")
  if (member.permissions.has("ManageMessages")) permissions.push("Mesajları Yönet")
  if (member.permissions.has("MentionEveryone")) permissions.push("@everyone Bahset")
  if (member.permissions.has("ManageWebhooks")) permissions.push("Webhook'ları Yönet")
  if (member.permissions.has("ManageEmojisAndStickers")) permissions.push("Emoji ve Çıkartmaları Yönet")

  return permissions
}
