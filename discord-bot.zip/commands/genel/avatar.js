const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, StringSelectMenuBuilder, ButtonStyle } = require("discord.js")

module.exports = {
  name: "avatar",
  description: "Kullanıcının avatarını gösterir.",
  async execute(message, args) {
    // Get the target user (mentioned user or message author)
    const user = message.mentions.users.first() || message.author

    // Default settings
    let format = "png"
    let size = 1024

    // Create the initial embed
    const createEmbed = (user, format, size) => {
      return new EmbedBuilder()
        .setTitle(`${user.username}'in Avatarı`)
        .setColor("#5865F2")
        .setImage(user.displayAvatarURL({ format: format, size: size, dynamic: true }))
        .setFooter({ text: `Format: ${format.toUpperCase()} | Boyut: ${size}px` })
        .setTimestamp()
    }

    // Create format buttons
    const formatRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("format_png").setLabel("PNG").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("format_jpeg").setLabel("JPEG").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("format_webp").setLabel("WEBP").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("format_gif")
        .setLabel("GIF")
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(!user.avatar?.startsWith("a_")),
    )

    // Create action buttons
    const actionRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("open_designer").setLabel("Tasarımcıda Aç").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setLabel("İndir")
        .setStyle(ButtonStyle.Link)
        .setURL(user.displayAvatarURL({ format: format, size: size, dynamic: true })),
    )

    // Create size select menu
    const sizeRow = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId("avatar_size")
        .setPlaceholder("Avatar Boyutunu Seçin")
        .addOptions([
          { label: "128px", value: "128" },
          { label: "256px", value: "256" },
          { label: "512px", value: "512" },
          { label: "1024px", value: "1024", default: true },
          { label: "2048px", value: "2048" },
          { label: "4096px", value: "4096" },
        ]),
    )

    // Send the initial message with components
    const avatarMessage = await message.channel.send({
      embeds: [createEmbed(user, format, size)],
      components: [formatRow, sizeRow, actionRow],
    })

    // Create a collector for button interactions
    const collector = avatarMessage.createMessageComponentCollector({ time: 60000 })

    collector.on("collect", async (interaction) => {
      // Ensure the interaction is from the command user
      if (interaction.user.id !== message.author.id) {
        return interaction.reply({
          content: "Bu komutu sadece çalıştıran kişi kullanabilir!",
          ephemeral: true,
        })
      }

      // Handle format buttons
      if (interaction.customId.startsWith("format_")) {
        format = interaction.customId.replace("format_", "")

        // Update the download button URL with a new button
        const newActionRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("open_designer").setLabel("Tasarımcıda Aç").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setLabel("İndir")
            .setStyle(ButtonStyle.Link)
            .setURL(user.displayAvatarURL({ format: format, size: size, dynamic: true })),
        )

        await interaction.update({
          embeds: [createEmbed(user, format, size)],
          components: [formatRow, sizeRow, newActionRow],
        })
      }

      // Handle size select menu
      else if (interaction.customId === "avatar_size") {
        size = Number.parseInt(interaction.values[0])

        // Update the download button URL with a new button
        const newActionRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("open_designer").setLabel("Tasarımcıda Aç").setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setLabel("İndir")
            .setStyle(ButtonStyle.Link)
            .setURL(user.displayAvatarURL({ format: format, size: size, dynamic: true })),
        )

        await interaction.update({
          embeds: [createEmbed(user, format, size)],
          components: [formatRow, sizeRow, newActionRow],
        })
      }

      // Handle open in designer button
      else if (interaction.customId === "open_designer") {
        await interaction.reply({
          content: `Avatar tasarımcıda açıldı: ${user.displayAvatarURL({ format: format, size: size, dynamic: true })}`,
          ephemeral: true,
        })
      }
    })

    collector.on("end", () => {
      // Disable all components when the collector ends
      formatRow.components.forEach((button) => button.setDisabled(true))
      sizeRow.components.forEach((menu) => menu.setDisabled(true))

      // Create a new action row with disabled buttons
      const disabledActionRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("open_designer")
          .setLabel("Tasarımcıda Aç")
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(true),
        new ButtonBuilder()
          .setLabel("İndir")
          .setStyle(ButtonStyle.Link)
          .setURL(user.displayAvatarURL({ format: format, size: size, dynamic: true })),
      )

      avatarMessage
        .edit({
          components: [formatRow, sizeRow, disabledActionRow],
        })
        .catch(console.error)
    })
  },
}
