const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require("discord.js")

module.exports = {
  name: "sunucu",
  description: "Sunucu hakkında detaylı bilgi verir.",
  async execute(message, args) {
    const guild = message.guild

    try {
      // Fetch more guild data if needed
      await guild.fetch()

      // Get guild owner
      const owner = await guild.fetchOwner()

      // Calculate dates
      const createdAt = Math.floor(guild.createdTimestamp / 1000)

      // Get member counts
      const totalMembers = guild.memberCount
      const botCount = guild.members.cache.filter((member) => member.user.bot).size
      const humanCount = totalMembers - botCount

      // Get channel counts
      const textChannels = guild.channels.cache.filter((c) => c.type === ChannelType.GuildText).size
      const voiceChannels = guild.channels.cache.filter((c) => c.type === ChannelType.GuildVoice).size
      const categoryChannels = guild.channels.cache.filter((c) => c.type === ChannelType.GuildCategory).size
      const announcementChannels = guild.channels.cache.filter((c) => c.type === ChannelType.GuildAnnouncement).size
      const stageChannels = guild.channels.cache.filter((c) => c.type === ChannelType.GuildStageVoice).size
      const forumChannels = guild.channels.cache.filter((c) => c.type === ChannelType.GuildForum).size
      const threadChannels = guild.channels.cache.filter(
        (c) =>
          c.type === ChannelType.PublicThread ||
          c.type === ChannelType.PrivateThread ||
          c.type === ChannelType.AnnouncementThread,
      ).size

      // Get emoji counts
      const regularEmojis = guild.emojis.cache.filter((emoji) => !emoji.animated).size
      const animatedEmojis = guild.emojis.cache.filter((emoji) => emoji.animated).size
      const totalEmojis = regularEmojis + animatedEmojis

      // Get sticker count
      const stickerCount = guild.stickers.cache.size

      // Get boost info
      const boostLevel = guild.premiumTier
      const boostCount = guild.premiumSubscriptionCount

      // Get verification level
      const verificationLevel = getVerificationLevel(guild.verificationLevel)

      // Get content filter level
      const contentFilter = getContentFilterLevel(guild.explicitContentFilter)

      // Get features
      const features =
        guild.features.length > 0 ? guild.features.map((feature) => `\`${formatFeature(feature)}\``).join(", ") : "Yok"

      // Create embed
      const embed = new EmbedBuilder()
        .setTitle(`${guild.name} Sunucu Bilgisi`)
        .setColor("#5865F2")
        .setThumbnail(guild.iconURL({ size: 1024, dynamic: true }))
        .addFields(
          {
            name: "📋 Genel Bilgiler",
            value:
              `**ID:** ${guild.id}\n` +
              `**Sahibi:** ${owner.user.tag} (${owner.id})\n` +
              `**Oluşturulma Tarihi:** <t:${createdAt}:F> (<t:${createdAt}:R>)\n` +
              `**Boost Seviyesi:** ${getBoostLevel(boostLevel)} (${boostCount} boost)\n` +
              `**Doğrulama Seviyesi:** ${verificationLevel}\n` +
              `**İçerik Filtresi:** ${contentFilter}\n` +
              `**Varsayılan Bildirimler:** ${guild.defaultMessageNotifications === 0 ? "Tüm Mesajlar" : "Sadece @mentions"}`,
          },
          {
            name: "👥 Üye Bilgileri",
            value:
              `**Toplam Üye:** ${totalMembers}\n` +
              `**İnsan Üye:** ${humanCount}\n` +
              `**Bot Üye:** ${botCount}\n` +
              `**Rol Sayısı:** ${guild.roles.cache.size}`,
          },
          {
            name: "📢 Kanal Bilgileri",
            value:
              `**Toplam Kanal:** ${guild.channels.cache.size}\n` +
              `**Metin Kanalları:** ${textChannels}\n` +
              `**Ses Kanalları:** ${voiceChannels}\n` +
              `**Duyuru Kanalları:** ${announcementChannels}\n` +
              `**Sahne Kanalları:** ${stageChannels}\n` +
              `**Forum Kanalları:** ${forumChannels}\n` +
              `**Thread'ler:** ${threadChannels}\n` +
              `**Kategoriler:** ${categoryChannels}`,
          },
          {
            name: "😀 Emoji ve Çıkartma Bilgileri",
            value:
              `**Toplam Emoji:** ${totalEmojis}\n` +
              `**Normal Emoji:** ${regularEmojis}\n` +
              `**Hareketli Emoji:** ${animatedEmojis}\n` +
              `**Çıkartma Sayısı:** ${stickerCount}`,
          },
        )

      // Add server features if available
      if (guild.features.length > 0) {
        embed.addFields({ name: "✨ Sunucu Özellikleri", value: features })
      }

      // Add server banner if available
      if (guild.banner) {
        embed.setImage(guild.bannerURL({ size: 1024 }))
      }

      // Create buttons
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel("Sunucu Simgesi")
          .setStyle(ButtonStyle.Link)
          .setURL(guild.iconURL({ size: 4096, dynamic: true }) || "https://discord.com")
          .setDisabled(!guild.icon),
        new ButtonBuilder()
          .setLabel("Sunucu Afişi")
          .setStyle(ButtonStyle.Link)
          .setURL(guild.bannerURL({ size: 4096 }) || "https://discord.com")
          .setDisabled(!guild.banner),
        new ButtonBuilder()
          .setLabel("Davet Arkaplanı")
          .setStyle(ButtonStyle.Link)
          .setURL(guild.splashURL({ size: 4096 }) || "https://discord.com")
          .setDisabled(!guild.splash),
      )

      // Send the embed
      message.channel.send({ embeds: [embed], components: [row] })
    } catch (error) {
      console.error("Sunucu bilgisi alınırken hata oluştu:", error)
      message.channel.send("Sunucu bilgisi alınırken bir hata oluştu. Lütfen daha sonra tekrar deneyin.")
    }
  },
}

// Helper functions
function getVerificationLevel(level) {
  switch (level) {
    case 0:
      return "Yok (Hiçbir kısıtlama yok)"
    case 1:
      return "Düşük (E-posta doğrulanmış)"
    case 2:
      return "Orta (Discord'a 5+ dakika kayıtlı)"
    case 3:
      return "Yüksek (Sunucuya 10+ dakika üye)"
    case 4:
      return "Çok Yüksek (Doğrulanmış telefon)"
    default:
      return "Bilinmiyor"
  }
}

function getContentFilterLevel(level) {
  switch (level) {
    case 0:
      return "Devre Dışı (İçerik taranmıyor)"
    case 1:
      return "Üyeler İçin (Rol olmayan üyeler için tarama)"
    case 2:
      return "Tüm Üyeler İçin (Herkes için tarama)"
    default:
      return "Bilinmiyor"
  }
}

function getBoostLevel(level) {
  switch (level) {
    case 0:
      return "Seviye 0"
    case 1:
      return "Seviye 1"
    case 2:
      return "Seviye 2"
    case 3:
      return "Seviye 3"
    default:
      return "Bilinmiyor"
  }
}

function formatFeature(feature) {
  // Convert SCREAMING_SNAKE_CASE to Title Case With Spaces
  return feature
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ")
}
