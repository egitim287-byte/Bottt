const { SlashCommandBuilder } = require("discord.js")

module.exports = {
  name: "ping",
  description: "Botun gecikme süresini gösterir.",
  data: new SlashCommandBuilder().setName("ping").setDescription("Botun gecikme süresini gösterir"),
  execute(message, args) {
    message.channel.send(`🏓 Pong! API Gecikmesi: ${Math.round(message.client.ws.ping)}ms`)
  },
  async executeSlash(interaction) {
    await interaction.reply(`🏓 Pong! API Gecikmesi: ${Math.round(interaction.client.ws.ping)}ms`)
  },
}
