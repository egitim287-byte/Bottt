module.exports = {
  name: "guildMemberRemove",
  execute(member) {
    const channel = member.guild.channels.cache.find((ch) => ch.name === "güle-güle")
    if (!channel) return

    channel.send(`${member.user.tag} sunucudan ayrıldı. Güle güle! 👋`)
  },
}
