# Discord.js Bot - Slash Commands

Discord.js v14 ile geliştirilmiş, slash komutları destekleyen Türkçe Discord botu.

## Özellikler

### Genel Komutlar
- `/ping` - Botun gecikme süresini gösterir

### Roblox Komutları
- `/grup-bilgi` - Roblox grubunun bilgilerini gösterir
- `/kullanici-adi` - Roblox kullanıcı adını gösterir
- `/rutbe-ver` - Roblox grubunda kullanıcıya rütbe verir (Admin)
- `/rutbe-al` - Roblox grubunda kullanıcıdan rütbe alır (Admin)

### Moderasyon Komutları
- `/ban` - Bir kullanıcıyı sunucudan yasaklar (Ban yetkisi gerekli)
- `/unban` - Bir kullanıcının yasağını kaldırır (Ban yetkisi gerekli)

### Ticket Sistemi
- `/ticket-ac` - Yeni bir destek talebi oluşturur
- `/ticket-kapat` - Destek talebini kapatır (Kanal yönetimi yetkisi gerekli)

### Hoş Geldin/Güle Güle Sistemi
- Yeni üyeler katıldığında "hoş-geldin" kanalına resimli mesaj gönderir
- Üyeler ayrıldığında "güle-güle" kanalına mesaj gönderir

## Kurulum

1. Bağımlılıkları yükleyin:
\`\`\`bash
npm install
\`\`\`

2. `config.json` dosyasını düzenleyin:
   - Discord bot tokeninizi ekleyin
   - Roblox API anahtarınızı ekleyin (opsiyonel)

3. Botu başlatın:
\`\`\`bash
npm start
\`\`\`

## Gereksinimler

- Node.js v16.9.0 veya üzeri
- Discord.js v14
- @napi-rs/canvas (hoş geldin resimleri için)

## Notlar

- Slash komutları botun ilk başlatılmasında Discord'a kaydedilir
- Hoş geldin sistemi için "hoş-geldin" adında bir kanal oluşturun
- Güle güle sistemi için "güle-güle" adında bir kanal oluşturun
- Roblox rütbe verme/alma komutları için Roblox API anahtarı gereklidir
