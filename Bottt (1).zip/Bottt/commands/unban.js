const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js")

module.exports = {
  name: "unban",
  description: "Bir kullanıcının yasağını kaldırır.",
  data: new SlashCommandBuilder()
    .setName("unban")
    .setDescription("Bir kullanıcının yasağını kaldırır")
    .addStringOption((option) =>
      option.setName("kullanici-id").setDescription("Yasağı kaldırılacak kullanıcı ID'si").setRequired(true),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async executeSlash(interaction) {
    const kullaniciId = interaction.options.getString("kullanici-id")

    try {
      await interaction.guild.members.unban(kullaniciId)
      await interaction.reply(`✅ <@${kullaniciId}> kullanıcısının yasağı kaldırıldı!`)
    } catch (error) {
      console.error(error)
      await interaction.reply({ content: "Yasak kaldırılırken bir hata oluştu!", ephemeral: true })
    }
  },
}
