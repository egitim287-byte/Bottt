const { SlashCommandBuilder, EmbedBuilder } = require("discord.js")

module.exports = {
  name: "grup-bilgi",
  description: "Roblox grubunun bilgilerini gösterir.",
  data: new SlashCommandBuilder()
    .setName("grup-bilgi")
    .setDescription("Roblox grubunun bilgilerini gösterir")
    .addStringOption((option) => option.setName("grup-id").setDescription("Roblox grup ID'si").setRequired(true)),
  async executeSlash(interaction) {
    const grupId = interaction.options.getString("grup-id")

    try {
      const response = await fetch(`https://groups.roblox.com/v1/groups/${grupId}`)
      const data = await response.json()

      if (!response.ok) {
        return interaction.reply({ content: "Grup bulunamadı!", ephemeral: true })
      }

      const embed = new EmbedBuilder()
        .setTitle(data.name)
        .setDescription(data.description || "Açıklama yok")
        .addFields(
          { name: "Üye Sayısı", value: data.memberCount?.toString() || "Bilinmiyor", inline: true },
          { name: "Sahibi", value: data.owner?.username || "Bilinmiyor", inline: true },
          { name: "Herkese Açık", value: data.publicEntryAllowed ? "Evet" : "Hayır", inline: true },
        )
        .setColor("#00FF00")
        .setTimestamp()

      await interaction.reply({ embeds: [embed] })
    } catch (error) {
      console.error(error)
      await interaction.reply({ content: "Grup bilgileri alınırken bir hata oluştu!", ephemeral: true })
    }
  },
}
