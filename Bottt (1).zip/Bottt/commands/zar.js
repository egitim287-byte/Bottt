module.exports = {
  name: "zar",
  description: "Zar atar.",
  execute(message, args) {
    const result = Math.floor(Math.random() * 6) + 1
    message.channel.send(`🎲 Zar: **${result}**`)
  },
}
