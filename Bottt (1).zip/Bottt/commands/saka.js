module.exports = {
  name: "şaka",
  description: "Rastgele bir şaka yapar.",
  execute(message, args) {
    const jokes = [
      "Adamın biri güneşte yanmış, ay da düşüp kolunu kırmış!",
      "Yılanlardan korkma, yılmayanlardan kork.",
      "Aklımı kaçırdım, lütfen görürseniz haber verin.",
      "Geçen gün taksi çevirdim, hala dönüyor.",
      "Adamın kafası atmış, bacakları eşek.",
    ]

    const randomJoke = jokes[Math.floor(Math.random() * jokes.length)]
    message.channel.send(randomJoke)
  },
}
