module.exports = {
  name: "yardım",
  description: "Tüm komutları listeler.",
  execute(message, args, client) {
    let helpMessage = "**Komut Listesi**\n\n"

    // Get command folders
    const commandFolders = require("fs").readdirSync("./commands")

    // Loop through each folder
    for (const folder of commandFolders) {
      helpMessage += `**${folder.charAt(0).toUpperCase() + folder.slice(1)} Komutları**\n`

      // Get commands in the folder
      const commandFiles = require("fs")
        .readdirSync(`./commands/${folder}`)
        .filter((file) => file.endsWith(".js"))

      // Loop through each command
      for (const file of commandFiles) {
        const command = require(`../${folder}/${file}`)
        helpMessage += `\`${client.config.prefix}${command.name}\`: ${command.description}\n`
      }

      helpMessage += "\n"
    }

    message.channel.send(helpMessage)
  },
}
