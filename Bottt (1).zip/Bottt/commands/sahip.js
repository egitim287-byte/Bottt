const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js")

module.exports = {
  name: "sahip",
  description: "Sunucu sahibini gösterir.",
  async execute(message, args) {
    try {
      // Fetch the guild owner
      const owner = await message.guild.fetchOwner()

      // Calculate dates
      const accountCreatedAt = Math.floor(owner.user.createdTimestamp / 1000)
      const joinedAt = Math.floor(owner.joinedTimestamp / 1000)
      const serverCreatedAt = Math.floor(message.guild.createdTimestamp / 1000)

      // Get owner's roles (excluding @everyone)
      const roles = owner.roles.cache
        .filter((role) => role.id !== message.guild.id)
        .sort((a, b) => b.position - a.position)
        .map((role) => role.toString())

      // Get owner's presence info
      const status = owner.presence ? getStatusEmoji(owner.presence.status) : "⚫ Çevrimdışı"
      const activity = owner.presence?.activities[0]
        ? `${getActivityTypeEmoji(owner.presence.activities[0].type)} ${owner.presence.activities[0].name}`
        : "Yok"

      // Get member count
      const totalMembers = message.guild.memberCount

      // Create embed
      const embed = new EmbedBuilder()
        .setAuthor({
          name: `${message.guild.name} Sunucusunun Sahibi`,
          iconURL: message.guild.iconURL({ dynamic: true }),
        })
        .setTitle(`👑 ${owner.user.tag}`)
        .setDescription(`Bu sunucunun sahibi **${owner.user.username}**'dir.`)
        .setColor(owner.displayHexColor || "#FFD700") // Gold color for owner
        .setThumbnail(owner.user.displayAvatarURL({ size: 1024, dynamic: true }))
        .addFields(
          {
            name: "👤 Kullanıcı Bilgileri",
            value:
              `**ID:** ${owner.id}\n` +
              `**Hesap Oluşturulma:** <t:${accountCreatedAt}:F> (<t:${accountCreatedAt}:R>)\n` +
              `**Durum:** ${status}\n` +
              `**Aktivite:** ${activity}`,
          },
          {
            name: "🏰 Sunucu Bilgileri",
            value:
              `**Sunucuya Katılma:** <t:${joinedAt}:F> (<t:${joinedAt}:R>)\n` +
              `**Sunucu Oluşturulma:** <t:${serverCreatedAt}:F> (<t:${serverCreatedAt}:R>)\n` +
              `**Yönettiği Üye Sayısı:** ${totalMembers} üye`,
          },
        )
        .setFooter({ text: "Sunucu sahibi tüm yetkilere sahiptir" })
        .setTimestamp()

      // Add roles if available
      if (roles.length > 0) {
        embed.addFields({
          name: `🎭 Roller [${roles.length}]`,
          value:
            roles.length > 10 ? roles.slice(0, 10).join(", ") + ` ve ${roles.length - 10} daha...` : roles.join(", "),
        })
      }

      // Create buttons
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("message_owner")
          .setLabel("Mesaj Gönder")
          .setStyle(ButtonStyle.Secondary)
          .setEmoji("✉️"),
        new ButtonBuilder()
          .setLabel("Profil")
          .setStyle(ButtonStyle.Link)
          .setURL(`https://discord.com/users/${owner.id}`)
          .setEmoji("👤"),
        new ButtonBuilder()
          .setLabel("Avatar")
          .setStyle(ButtonStyle.Link)
          .setURL(owner.user.displayAvatarURL({ size: 4096, dynamic: true }))
          .setEmoji("🖼️"),
      )

      // Send the embed
      const response = await message.channel.send({ embeds: [embed], components: [row] })

      // Create a collector for button interactions
      const collector = response.createMessageComponentCollector({ time: 60000 })

      collector.on("collect", async (interaction) => {
        if (interaction.customId === "message_owner") {
          // Check if the user can message the owner
          if (owner.id === interaction.user.id) {
            await interaction.reply({ content: "Kendinize mesaj gönderemezsiniz!", ephemeral: true })
            return
          }

          try {
            await interaction.reply({
              content: "Sunucu sahibine DM üzerinden mesaj gönderebilirsiniz. Lütfen saygılı olun!",
              ephemeral: true,
            })
          } catch (error) {
            console.error("Etkileşim yanıtlanırken hata oluştu:", error)
          }
        }
      })

      collector.on("end", () => {
        // Disable all components when the collector ends
        const disabledRow = new ActionRowBuilder().addComponents(
          ButtonBuilder.from(row.components[0]).setDisabled(true),
          row.components[1],
          row.components[2],
        )

        response.edit({ components: [disabledRow] }).catch(console.error)
      })
    } catch (error) {
      console.error("Sunucu sahibi bilgisi alınırken hata oluştu:", error)
      message.channel.send("Sunucu sahibi bilgisi alınırken bir hata oluştu. Lütfen daha sonra tekrar deneyin.")
    }
  },
}

// Helper functions
function getStatusEmoji(status) {
  switch (status) {
    case "online":
      return "🟢 Çevrimiçi"
    case "idle":
      return "🟡 Boşta"
    case "dnd":
      return "🔴 Rahatsız Etmeyin"
    case "invisible":
    case "offline":
    default:
      return "⚫ Çevrimdışı"
  }
}

function getActivityTypeEmoji(type) {
  switch (type) {
    case 0:
      return "🎮" // Playing
    case 1:
      return "🎥" // Streaming
    case 2:
      return "🎧" // Listening
    case 3:
      return "👀" // Watching
    case 4:
      return "🏆" // Competing
    case 5:
      return "🎭" // Custom
    default:
      return "📱"
  }
}
