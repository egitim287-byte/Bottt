const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js")

module.exports = {
  name: "rutbe-ver",
  description: "Roblox grubunda kullanıcıya rütbe verir.",
  data: new SlashCommandBuilder()
    .setName("rutbe-ver")
    .setDescription("Roblox grubunda kullanıcıya rütbe verir")
    .addStringOption((option) => option.setName("grup-id").setDescription("Roblox grup ID'si").setRequired(true))
    .addStringOption((option) =>
      option.setName("kullanici-id").setDescription("Roblox kullanıcı ID'si").setRequired(true),
    )
    .addIntegerOption((option) => option.setName("rutbe-id").setDescription("Verilecek rütbe ID'si").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  async executeSlash(interaction) {
    const grupId = interaction.options.getString("grup-id")
    const kullaniciId = interaction.options.getString("kullanici-id")
    const rutbeId = interaction.options.getInteger("rutbe-id")

    await interaction.reply({
      content: `⚠️ Rütbe verme işlemi için Roblox API anahtarı gereklidir. Bu özellik şu anda manuel olarak yapılandırılmalıdır.\n\nGrup ID: ${grupId}\nKullanıcı ID: ${kullaniciId}\nRütbe ID: ${rutbeId}`,
      ephemeral: true,
    })
  },
}
