const { SlashCommandBuilder, EmbedBuilder } = require("discord.js")

module.exports = {
  name: "kullanici-adi",
  description: "Roblox kullanıcı adını gösterir.",
  data: new SlashCommandBuilder()
    .setName("kullanici-adi")
    .setDescription("Roblox kullanıcı adını gösterir")
    .addStringOption((option) =>
      option.setName("kullanici-id").setDescription("Roblox kullanıcı ID'si").setRequired(true),
    ),
  async executeSlash(interaction) {
    const kullaniciId = interaction.options.getString("kullanici-id")

    try {
      const response = await fetch(`https://users.roblox.com/v1/users/${kullaniciId}`)
      const data = await response.json()

      if (!response.ok) {
        return interaction.reply({ content: "Kullanıcı bulunamadı!", ephemeral: true })
      }

      const embed = new EmbedBuilder()
        .setTitle("Roblox Kullanıcı Bilgisi")
        .addFields(
          { name: "Kullanıcı Adı", value: data.name, inline: true },
          { name: "Görünen Ad", value: data.displayName, inline: true },
          { name: "Kullanıcı ID", value: data.id.toString(), inline: true },
        )
        .setThumbnail(
          `https://www.roblox.com/headshot-thumbnail/image?userId=${kullaniciId}&width=420&height=420&format=png`,
        )
        .setColor("#0099FF")
        .setTimestamp()

      await interaction.reply({ embeds: [embed] })
    } catch (error) {
      console.error(error)
      await interaction.reply({ content: "Kullanıcı bilgileri alınırken bir hata oluştu!", ephemeral: true })
    }
  },
}
