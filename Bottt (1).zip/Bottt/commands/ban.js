const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js")

module.exports = {
  name: "ban",
  description: "Bir kullanıcıyı sunucudan yasaklar.",
  data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Bir kullanıcıyı sunucudan yasaklar")
    .addUserOption((option) => option.setName("kullanici").setDescription("Yasaklanacak kullanıcı").setRequired(true))
    .addStringOption((option) => option.setName("sebep").setDescription("Yasaklama sebebi").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async executeSlash(interaction) {
    const kullanici = interaction.options.getUser("kullanici")
    const sebep = interaction.options.getString("sebep") || "Sebep belirtilmedi"

    try {
      await interaction.guild.members.ban(kullanici, { reason: sebep })
      await interaction.reply(`✅ ${kullanici.tag} başarıyla yasaklandı!\nSebep: ${sebep}`)
    } catch (error) {
      console.error(error)
      await interaction.reply({ content: "Kullanıcı yasaklanırken bir hata oluştu!", ephemeral: true })
    }
  },
}
